#Define cnVersion         			1.45.23
#Define cdVersionDate     			May 27, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.23 - May 27, 2023- 20230527'
#Define	ccThorVERSION     			[Thor - 1.45.23 - May 27, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]