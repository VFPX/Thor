#Define cnVersion         			1.45.15
#Define cdVersionDate     			April 2, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.15 - April 2, 2023- 20230402'
#Define	ccThorVERSION     			[Thor - 1.45.15 - April 2, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]