* 1.45.01

#Define cnVersion         1.45.04
#Define cdVersionDate     January 6, 2023
#Define	ccThorInternalVERSION     [Thor - 1.45.04 - January 6, 2023]
#Define	ccThorVERSION     [Thor - 1.45.04 - January 6, 2023]
#Define	ccThorVERSIONFILE [ThorVersion.txt]