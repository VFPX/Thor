#Define cnVersion         			1.45.17
#Define cdVersionDate     			April 6, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.17 - April 6, 2023- 20230406'
#Define	ccThorVERSION     			[Thor - 1.45.17 - April 6, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]