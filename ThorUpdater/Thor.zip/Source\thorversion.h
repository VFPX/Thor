* 1.45.01

#Define cnVersion         1.45.02
#Define cdVersionDate     December 26, 2022
#Define	ccThorInternalVERSION     [Thor - 1.45.02 - December 26, 2022- 20221226]
#Define	ccThorVERSION     [Thor - 1.45.02 - December 26, 2022]
#Define	ccThorVERSIONFILE [ThorVersion.txt]