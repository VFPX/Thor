#Define cnVersion         			1.47.01
#Define cdVersionDate     			January 5, 2024
#Define	ccThorInternalVERSION     	'Thor - 1.47.01 - January 5 2024- 20240105'
#Define	ccThorVERSION     			[Thor - 1.47.01 - January 5, 2024]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]