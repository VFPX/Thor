#Define cnVersion         			1.45.18
#Define cdVersionDate     			April 8, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.18 - April 8, 2023- 20230408'
#Define	ccThorVERSION     			[Thor - 1.45.18 - April 8, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]