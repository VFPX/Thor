#Define cnVersion         			1.45.27
#Define cdVersionDate     			July 22, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.27 - July 22, 2023- 20230722'
#Define	ccThorVERSION     			[Thor - 1.45.27 - July 22, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]