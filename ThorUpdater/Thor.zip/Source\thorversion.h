#Define cnVersion         			1.47.04
#Define cdVersionDate     			December 4, 2024
#Define	ccThorInternalVERSION     	'Thor - 1.47.04 - December 4, 2024 - 20241204'
#Define	ccThorVERSION     			[Thor - 1.47.04 - December 4, 2024]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]