#Define cnVersion         			1.46.08
#Define cdVersionDate     			October 20, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.08 - October 20, 2023- 20231020'
#Define	ccThorVERSION     			[Thor - 1.46.08 - October 20, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]