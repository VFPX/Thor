#Define cnVersion         			1.45.27
#Define cdVersionDate     			June 28, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.27 - June 28, 2023- 20230628'
#Define	ccThorVERSION     			[Thor - 1.45.27 - June 28, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]