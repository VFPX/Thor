#Define cnVersion         			1.45.08
#Define cdVersionDate     			March 16. 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.08 - March 16. 2023- 20230316'
#Define	ccThorVERSION     			[Thor - 1.45.08 - March 16. 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]