#Define cnVersion         			1.47
#Define cdVersionDate     			January 4, 2024
#Define	ccThorInternalVERSION     	'Thor - 1.47 - January 4 2024- 20240104'
#Define	ccThorVERSION     			[Thor - 1.47 - January 4, 2024]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]