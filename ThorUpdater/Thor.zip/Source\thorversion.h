* 1.45.01

#Define cnVersion         			1.45.06
#Define cdVersionDate     			January 20, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.06 - January 20, 2023- 20230120'
#Define	ccThorVERSION     			[Thor - 1.45.06 - January 20, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]