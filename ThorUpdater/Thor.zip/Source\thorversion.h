#Define cnVersion         			1.46.10
#Define cdVersionDate     			October 28, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.10 - October 28, 2023- 20231028'
#Define	ccThorVERSION     			[Thor - 1.46.10 - October 28, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]