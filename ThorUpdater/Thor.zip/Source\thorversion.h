#Define cnVersion         			1.45.26
#Define cdVersionDate     			June 21, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.26 - June 21, 2023- 20230621'
#Define	ccThorVERSION     			[Thor - 1.45.26 - June 21, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]