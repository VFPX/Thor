#Define cnVersion         			1.46.16
#Define cdVersionDate     			December 5, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.16 - December 5, 2023- 20231205'
#Define	ccThorVERSION     			[Thor - 1.46.16 - December 5, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]