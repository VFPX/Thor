#Define cnVersion         			1.46
#Define cdVersionDate     			August 11, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46 - August 11, 2023- 20230811'
#Define	ccThorVERSION     			[Thor - 1.46 - August 11, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]