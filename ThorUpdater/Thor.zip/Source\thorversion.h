#Define cnVersion         			1.47.03
#Define cdVersionDate     			October 12, 2024
#Define	ccThorInternalVERSION     	'Thor - 1.47.03 - October 12, 2024 - 20241012'
#Define	ccThorVERSION     			[Thor - 1.47.03 - October 12, 2024]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]