#Define cnVersion         			1.45.20
#Define cdVersionDate     			May 20, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.20 - May 20, 2023- 20230520'
#Define	ccThorVERSION     			[Thor - 1.45.20 - May 20, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]