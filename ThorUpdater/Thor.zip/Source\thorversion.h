#Define cnVersion         			1.46.07
#Define cdVersionDate     			October 13, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.07 - October 13, 2023- 20231013'
#Define	ccThorVERSION     			[Thor - 1.46.07 - October 13, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]