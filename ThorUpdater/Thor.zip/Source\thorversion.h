#Define cnVersion         			1.46.14
#Define cdVersionDate     			November 26, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.14 - November 26, 2023- 20231126'
#Define	ccThorVERSION     			[Thor - 1.46.14 - November 26, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]