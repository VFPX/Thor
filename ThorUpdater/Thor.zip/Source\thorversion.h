#Define cnVersion         			1.47.02
#Define cdVersionDate     			January 13, 2024
#Define	ccThorInternalVERSION     	'Thor - 1.47.02 - January 13 2024- 20240113'
#Define	ccThorVERSION     			[Thor - 1.47.02 - January 13, 2024]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]