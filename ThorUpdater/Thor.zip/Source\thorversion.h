* 1.45.01

#Define cnVersion         1.45.01
#Define cdVersionDate     December 13, 2022
#Define	ccThorInternalVERSION     [Thor - 1.45.01 - December 13, 2022- 20221213]
#Define	ccThorVERSION     [Thor - 1.45.01 - December 13, 2022]
#Define	ccThorVERSIONFILE [ThorVersion.txt]