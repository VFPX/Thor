#Define cnVersion         			1.45.09
#Define cdVersionDate     			March 19, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.09 - March 19, 2023- 20230319'
#Define	ccThorVERSION     			[Thor - 1.45.09 - March 19, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]