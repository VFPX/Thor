#Define cnVersion         			1.46.06
#Define cdVersionDate     			September 29, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.06 - September 29, 2023- 20230929'
#Define	ccThorVERSION     			[Thor - 1.46.06 - September 29, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]