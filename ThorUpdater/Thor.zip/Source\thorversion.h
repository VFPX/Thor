#Define cnVersion         			1.45.10
#Define cdVersionDate     			March 21, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.10 - March 21, 2023- 20230321'
#Define	ccThorVERSION     			[Thor - 1.45.10 - March 21, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]