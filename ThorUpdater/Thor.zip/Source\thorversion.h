#Define cnVersion         			1.46.09
#Define cdVersionDate     			October 22, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.09 - October 22, 2023- 20231022'
#Define	ccThorVERSION     			[Thor - 1.46.09 - October 22, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]