#Define cnVersion         			1.45.21
#Define cdVersionDate     			May 20, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.21 - May 20, 2023- 20230520'
#Define	ccThorVERSION     			[Thor - 1.45.21 - May 20, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]