#Define cnVersion         			1.46.04
#Define cdVersionDate     			September 28, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.04 - September 28, 2023- 20230928'
#Define	ccThorVERSION     			[Thor - 1.46.04 - September 28, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]