#Define cnVersion         			1.46.17
#Define cdVersionDate     			December 16, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.17 - December 16, 2023- 20231216'
#Define	ccThorVERSION     			[Thor - 1.46.17 - December 16, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]