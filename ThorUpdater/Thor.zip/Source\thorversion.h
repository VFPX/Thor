#Define cnVersion         			1.45.28A
#Define cdVersionDate     			August 5, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.28A - August 5, 2023- 20230805'
#Define	ccThorVERSION     			[Thor - 1.45.28A - August 5, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]