#Define cnVersion         			1.46.10
#Define cdVersionDate     			October 25, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.10 - October 25, 2023- 20231025'
#Define	ccThorVERSION     			[Thor - 1.46.10 - October 25, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]