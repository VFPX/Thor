#Define cnVersion         			1.46.13
#Define cdVersionDate     			November 15, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.13 - November 15, 2023- 20231115'
#Define	ccThorVERSION     			[Thor - 1.46.13 - November 15, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]