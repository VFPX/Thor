#Define cnVersion         			1.45.25
#Define cdVersionDate     			June 11, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.25 - June 11, 2023- 20230611'
#Define	ccThorVERSION     			[Thor - 1.45.25 - June 11, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]