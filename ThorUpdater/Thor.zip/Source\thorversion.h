#Define cnVersion         			1.45.24
#Define cdVersionDate     			June 10, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.24 - June 10, 2023- 20230610'
#Define	ccThorVERSION     			[Thor - 1.45.24 - June 10, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]