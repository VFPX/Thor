#Define cnVersion         			1.46.11
#Define cdVersionDate     			October 30, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.11 - October 30, 2023- 20231130'
#Define	ccThorVERSION     			[Thor - 1.46.11 - October 30, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]