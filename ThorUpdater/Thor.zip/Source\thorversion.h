#Define cnVersion         			1.45.11
#Define cdVersionDate     			March 23, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.12 - March 23, 2023- 20230323'
#Define	ccThorVERSION     			[Thor - 1.45.12 - March 23, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]