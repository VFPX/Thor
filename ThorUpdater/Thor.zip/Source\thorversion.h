#Define cnVersion         			1.46.03
#Define cdVersionDate     			August 26, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.03 - August 26, 2023- 20230826'
#Define	ccThorVERSION     			[Thor - 1.46.03 - August 26, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]