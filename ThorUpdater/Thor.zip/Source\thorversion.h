#Define cnVersion         			1.46.01
#Define cdVersionDate     			August 13, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.01 - August 13, 2023- 20230813'
#Define	ccThorVERSION     			[Thor - 1.46.01 - August 13, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]