#Define cnVersion         			1.45.13
#Define cdVersionDate     			March 24, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.13 - March 24, 2023- 20230324'
#Define	ccThorVERSION     			[Thor - 1.45.13 - March 24, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]