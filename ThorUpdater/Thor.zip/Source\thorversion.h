#Define cnVersion         			1.46.12
#Define cdVersionDate     			November 11, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.12 - November 11, 2023- 20231111'
#Define	ccThorVERSION     			[Thor - 1.46.12 - November 11, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]