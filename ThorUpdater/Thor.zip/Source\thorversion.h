#Define cnVersion         			1.46.01
#Define cdVersionDate     			August 19, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.01 - August 19, 2023- 20230819'
#Define	ccThorVERSION     			[Thor - 1.46.01 - August 19, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]