#Define cnVersion         			1.45.28C
#Define cdVersionDate     			August 6, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.45.28C - August 6, 2023- 20230806'
#Define	ccThorVERSION     			[Thor - 1.45.28C - August 6, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]