#Define cnVersion         			1.46.15
#Define cdVersionDate     			November 27, 2023
#Define	ccThorInternalVERSION     	'Thor - 1.46.15 - November 27, 2023- 20231127'
#Define	ccThorVERSION     			[Thor - 1.46.15 - November 27, 2023]
#Define	ccThorVERSIONFILE 			[ThorVersion.txt]