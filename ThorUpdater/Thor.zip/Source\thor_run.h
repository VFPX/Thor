#include Thor_UI.H

#Define  	ccRUN	 			'Run' 

#Define  	ccPOPUPID 			'PopupID=' 

#Define		ccTOOLFOLDER		'Tool Folder='

#Define		ccGETVERSION 		'Version='

#Define		ccTHORENGINE		'Thor Engine='

#Define     ccThorRegister      'Thor Register='

#Define     ccTOOLTEMPLATE      'Thor Template Code=' 

#Define     ccThorClearHotKeys  'Clear HotKeys'

#Define     ccClass  			'Class='

#Define     ccLink  			'Link='

#Define     ccModify  			'Edit='

#Define     ccResult  			'Result='

#Define     ccToolInfo  		'ToolInfo='

#Define     ccDoDefault  		'DoDefault()'

#Define     ccFullPath  		'Full Path='

#Define     ccThorMemberData    '<VFPData><memberdata name="cthordispatcher" display="cThorDispatcher"/><memberdata name="lthordebugmode" display="lThorDebugMode"/></VFPData>'

