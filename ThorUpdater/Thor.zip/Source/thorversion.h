* 1.44

*** DH 2022-03-04: changed version information
#Define cnVersion         1.44
#Define cdVersionDate     March 4, 2022
#Define	ccThorInternalVERSION     [Thor - 1.44 - March 4, 2022- 20220304]
#Define	ccThorVERSION     [Thor - 1.44 - March 4, 2022]
#Define	ccThorVERSIONFILE [ThorVersion.txt]