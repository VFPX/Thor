* 1.45

#Define cnVersion         1.45
#Define cdVersionDate     March 5, 2022
#Define	ccThorInternalVERSION     [Thor - 1.45 - March 5, 2022- 20220305]
#Define	ccThorVERSION     [Thor - 1.45 - March 5, 2022]
#Define	ccThorVERSIONFILE [ThorVersion.txt]