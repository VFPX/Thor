* 1.43

*** DH 2021-12-28: changed version information
#Define cnVersion         1.43
#Define cdVersionDate     December 28, 2021
#Define	ccThorInternalVERSION     [Thor - 1.43 - December 28, 2021- 20211228]
#Define	ccThorVERSION     [Thor - 1.43 - December 28, 2021]
#Define	ccThorVERSIONFILE [ThorVersion.txt]