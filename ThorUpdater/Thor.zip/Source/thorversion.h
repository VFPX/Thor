* 1.43

#Define cnVersion         1.43
#Define cdVersionDate     December 25, 2021
#Define	ccThorInternalVERSION     [Thor - 1.43 - December 25, 2021- 20211225]
#Define	ccThorVERSION     [Thor - 1.43 - December 25, 2021]
#Define	ccThorVERSIONFILE [ThorVersion.txt]